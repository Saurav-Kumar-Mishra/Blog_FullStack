import React from 'react'

function BlogAuthor() {
  return (
    <div>
      
    </div>
  )
}

export default BlogAuthor
