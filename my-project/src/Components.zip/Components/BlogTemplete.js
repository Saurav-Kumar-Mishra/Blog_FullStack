import React from 'react'
import BlogContent from './BlogContent'
import ImgCard from './ImgCard'

function BlogTemplete() {
  return (
    <div>
        <ImgCard/>
        <BlogContent/>
    </div>
  )
}

export default BlogTemplete
