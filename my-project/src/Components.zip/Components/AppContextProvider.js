import React, { createContext} from "react";

export const User = createContext();

export default function AppContextProvider({ children }) {
  const [isLogged, setIsLogged] = React.useState(false);
  const [user, setUser]=React.useState(null);
  
  const value = {
    isLogged,
    setIsLogged,
    user,
    setUser
  };

  return <User.Provider value={value}>{children}</User.Provider>;
}

