export default [
  {
      id:1,
      img:"../img1.jpg",
  },
  {
    id:2,
    img:"../img2.jpg",
},
{
  id:3,
  img:"../img3.jpg",
},
{
  id:4,
  img:"../img4.jpg",
},
  
]
